package Modelo;

import java.util.List;

public class GestorDeTrackerBitTorrent {
	
	public GestorDeTrackerBitTorrent() {
		
	}
	
	public List<String> listaPeers(String torrent) {
		return null;
	}
}
